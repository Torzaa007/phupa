import { writable } from 'svelte/store';

// Store สำหรับเก็บข้อมูลที่นั่งและข้อมูลผู้โดยสาร
export const passengerInfo = writable({
    firstName: '',
    lastName: '',
    citizenID: '',
    phoneNumber: '',
    selectedTrip: null,
    selectedSeatType: '',
    seatCount: 1
});