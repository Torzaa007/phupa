<script>
    import { onMount } from "svelte";
    import { page } from '$app/stores';
    
    let ticketData = {};
    
    // Fetch ticket details (You would replace this with your SQLite DB fetch logic)
    // Retrieve passenger data from URL query parameters
    $: passenger = {
        name: $page.url.searchParams.get('name') || 'N/A',
        phone: $page.url.searchParams.get('phone') || 'N/A',
        citizenID: $page.url.searchParams.get('citizenID') || 'N/A',
        tripNumber: $page.url.searchParams.get('tripNumber') || 'N/A',
        from: $page.url.searchParams.get('from') || 'N/A',
        to: $page.url.searchParams.get('to') || 'N/A',
        travelDate: $page.url.searchParams.get('travelDate') || 'N/A',
        seatType: $page.url.searchParams.get('seatType') || 'N/A',
        amount: $page.url.searchParams.get('amount') || 'N/A',
        price: $page.url.searchParams.get('price') || 'N/A',
        coachId: $page.url.searchParams.get('coachId') || 'N/A',
        seatId: $page.url.searchParams.get('seatId') || 'N/A'

    };
    
  </script>
  
  <nav class="bg-[#EADBC8] shadow-xl border">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex justify-between h-24">
        <div class="flex">
          <!-- Logo -->
          <div class="flex-shrink-0 flex items-center">
            <a href="/" class="text-2xl font-bold text-[#102C57]">OURTRAINS</a>
          </div>
        </div>
  
  </nav>
<div class=" bg-white min-h-screen">
    <div class=" mx-auto py-24 rounded-md sm:px-8">
        <div class="bg-[#DAC0A3] p-2 text-white">
          <h2 class="text-lg font-bold text-[#102C57]">OURTRAIN TICKETS</h2>
        </div>
        <div class="bg-[#F8F0E5] p-4">
            <div class="grid grid-cols-2">
              <p><strong>ชื่อ-นามสกุล:</strong> {passenger.name}</p>
              <p><strong>เบอร์โทรศัพท์:</strong> {passenger.phone}</p>
            </div>

            <div class="grid grid-cols-2">
                <p><strong>เที่ยวโดยสาร:</strong> {passenger.tripNumber}</p>
                <p><strong>วันที่/เวลาเดินทาง:</strong> {passenger.travelDate}</p>
            </div>
            <hr class="border-t-1 border-black my-4"> 
            <div class="grid grid-cols-2">
                <p><strong>สถานีต้นทาง:</strong> {passenger.from}</p>
                <p><strong>ที่นั่ง:</strong> {passenger.seatId}</p>
              </div>
              <div class="grid grid-cols-2">
                <p></p> <!-- Empty space to align "ขบวนที่" with "ที่นั่ง" -->
                <p><strong>ขบวนที่:</strong> {passenger.coachId}</p>
              </div>
            <div class="grid grid-cols-2">
                <p><strong>สถานีปลายทาง:</strong> {passenger.to}</p>
                <p><strong>ชั้นโดยสาร:</strong> {passenger.seatType}</p>
            </div>
            <hr class="border-t-1 border-black my-4"> 
          
          <!-- QR Code section -->
          <div>
            <img src="https://api.qrserver.com/v1/create-qr-code/?data={ticketData.qrCode}&size=100x100" alt="QR Code">
            <p>{ticketData.qrCode}</p>
          </div>
        </div>
        <!-- Button -->
        <div class="text-center py-8">
            <a href='/sell' class="bg-blue-800 text-white px-6 py-2 rounded-md">ออกตั๋ว</a>
          </div>
      </div>
</div>
  
  