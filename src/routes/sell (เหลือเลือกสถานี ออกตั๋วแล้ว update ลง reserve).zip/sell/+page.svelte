<script>
    export let data;
    import { goto } from '$app/navigation';

    // ตัวแปรสำหรับข้อมูลเที่ยวโดยสาร
    let trips = data.trips;
    let stations = data.stations;  // ใช้ stations ในการแสดง dropdown
    let selectedTrip = null;   // เก็บข้อมูลเที่ยวโดยสารที่เลือก
    let selectedSeatType = ''; // เก็บข้อมูลประเภทที่นั่งที่เลือก
    let amount = '';
    let totalPrice = 0;  // ราคารวมที่จะคำนวณ
    let coachId = '';    // เก็บข้อมูล coach_id ที่เลือก
    let selectedSeatId = '';   // เก็บข้อมูล seat_id ที่เลือก

    // ตัวแปรสำหรับการเลือกสถานีและวันที่
    let fromStation = '';
    let toStation = '';
    let travelDate = ''; // เก็บวันที่ที่เลือก

    // ตัวแปรข้อมูลผู้โดยสาร
    let firstName = '';
    let lastName = '';
    let citizenID = '';
    let phoneNumber = '';
    console.log(coachId);


    // ฟังก์ชันสำหรับยืนยันและนำข้อมูลไปแสดงในหน้าข้อมูล
    function confirmSelection() {
        if (selectedTrip && selectedSeatType && firstName && lastName && citizenID && phoneNumber) {
            totalPrice = (selectedTrip.price || 0) * parseInt(amount);
            coachId = selectedTrip.coach_id; // ดึงค่า coach_id จาก selectedTrip
            selectedSeatId = selectedTrip.seat_id; // ดึงค่า seat_id จาก selectedTrip

            const queryParams = new URLSearchParams({
                firstName: firstName,
                lastName: lastName,
                citizenID: citizenID,
                phoneNumber: phoneNumber,
                tripId: selectedTrip.trip_id || '', // Ensure trip_id exists
                start: selectedTrip.start || '',
                end: selectedTrip.end || '',
                travelDate: selectedTrip.from_datetime || '',
                seatType: selectedSeatType,
                coachId: coachId, // เพิ่ม coachId ใน query params
                amount: amount || '',
                totalPrice: totalPrice.toString() || '', // ส่งราคารวมไปด้วย
                seatId: selectedSeatId // ส่ง seat_id ไปด้วย
            }).toString();

            goto(`/sell/info?${queryParams}`);
        } else {
            alert("กรุณากรอกข้อมูลให้ครบถ้วน");
        }
    }
</script>

<nav class="bg-[#EADBC8] shadow-xl border">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-24">
            <div class="flex">
                <!-- Logo -->
                <div class="flex-shrink-0 flex items-center">
                    <a href="/" class="text-2xl font-bold text-[#102C57]">OURTRAINS</a>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="p-8 bg-white min-h-screen">
    <h1 class="text-3xl text-[#102C57] underline font-bold mb-6 text-center">ออกตั๋วโดยสาร</h1>

    <!-- ฟอร์มสำหรับเลือกข้อมูลการเดินทาง -->
    <div class="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-4">
        <!-- Dropdown สำหรับเลือกเส้นทางโดยสาร -->
        <select class="border p-2 rounded bg-gray-300" bind:value={fromStation}>
            <option value="">--เส้นทางโดยสาร--</option>
            <option value="st_ne">สายตะวันออกเฉียงเหนือ</option>
            <option value="st_nl">สายใต้</option>
        </select>
        <select class="border p-2 rounded bg-gray-300" bind:value={fromStation}>
            <option value="">--ต้นทาง--</option>
            {#each stations as station}
            <option value={station.station_id}>{station.station_name}</option>
            {/each}
        </select>
        <!-- Dropdown สำหรับเลือกปลายทาง -->
        <select class="border p-2 rounded bg-gray-300" bind:value={toStation}>
            <option value="">--ปลายทาง--</option>
            {#each stations as station}
            <option value={station.station_id}>{station.station_name}</option>
            {/each}
        </select>
        <input type="date" class="bg-gray-300 border p-2 rounded" placeholder="--วันที่เดินทาง--">
    </div>

    <!-- ปุ่มแสดงเที่ยวโดยสาร -->
    <button class="bg-[#102C57] text-white px-4 py-2 rounded mb-6">แสดงเที่ยวโดยสาร</button>

    <!-- รายละเอียดเที่ยวโดยสาร -->
    <div class="border-t mb-6"></div>
    <div class="overflow-auto max-h-96">
        {#each trips as trip}
        <div class="bg-gray-300 p-4 rounded mb-4 flex flex-col sm:flex-row justify-between items-start sm:items-center w-full">
            <div>
                <p class="font-bold">จาก {trip.start} - {trip.end} {trip.from_datetime}</p>
                <p>เที่ยวโดยสาร {trip.trip_id} {trip.start} - {trip.end} ประเภท ชั้น {trip.class}</p>
                <p>ออกเดินทาง {trip.from_datetime} ถึง {trip.arrivalTime}</p>
            </div>
            <button 
                class={`px-8 py-2 rounded ${selectedTrip === trip ? 'bg-green-500' : 'bg-[#102C57]'} text-white`} 
                on:click={() => selectedTrip = trip}>
                เลือก
            </button>
        </div>
        {/each}
    </div>

    <!-- ส่วนของการเลือกที่นั่ง -->
    {#if selectedTrip}
    <hr class="mb-6">
    <h2 class="text-xl font-bold mb-4">เลือกที่นั่ง</h2>
    <div class="grid grid-cols-3 gap-4 mb-6">
        <select class="bg-gray-300 border p-2 rounded" bind:value={selectedSeatType}>
            <option value="">ชั้นโดยสาร--ประเภทที่นั่ง</option>
            {#each trips as seatType}
                <option value={seatType.seat_type}>{seatType.seat_type}</option>
            {/each}
        </select>
        <select class="bg-gray-300 border p-2 rounded" bind:value={amount}>
            <option value="">--จำนวนที่นั่ง--</option>
            <option value="1"> 1 </option>
            <option value="2"> 2 </option>
            <option value="3"> 3 </option>
            <option value="4"> 4 </option>
        </select>
    </div>
    <!-- รายละเอียดของที่นั่ง -->
    <div class="grid grid-cols-4 gap-4 mb-4">
        {#each trips as seatType}
        <div>
            <p>{seatType.seat_type} ว่าง: {seatType.seat_per_coach}</p>
        </div>
        {/each}
    </div>
    {/if}

    <!-- ฟอร์มข้อมูลผู้โดยสาร -->
    {#if selectedTrip && selectedSeatType}
    <hr class="mb-6">
    <h2 class="text-xl font-bold mb-4">ข้อมูลผู้โดยสาร</h2>
    <div class="grid grid-cols-4 gap-4 mb-4">
        <input type="text" class="border p-2 rounded" placeholder="ชื่อ" bind:value={firstName} required>
        <input type="text" class="border p-2 rounded" placeholder="นามสกุล" bind:value={lastName}>
        <input type="text" class="border p-2 rounded" placeholder="รหัสประจำตัวประชาชน" bind:value={citizenID}>
        <input type="text" class="border p-2 rounded" placeholder="เบอร์โทรศัพท์" bind:value={phoneNumber}>
    </div>
    <div class="mt-4 flex items-center justify-center bg-white">
        <button on:click={confirmSelection} class="bg-[#102C57] text-white px-4 py-2 rounded-md">
            ยืนยัน
        </button>
    </div>
    {/if}

</div>
